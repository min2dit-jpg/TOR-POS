namespace TorPos.Core;

[Flags]
public enum UserPermissions : long
{
    None = 0,
    Sale = 1L << 0,
    Discount = 1L << 1,
    ImmediateStorno = 1L << 2,
    ReceiptStorno = 1L << 3,
    ParkReceipts = 1L << 4,
    CashMovement = 1L << 5,
    ZReport = 1L << 6,
    ManageProducts = 1L << 7,
    ViewReceiptHistory = 1L << 8,
    Training = 1L << 9
}

public sealed record AuthenticatedUser(
    long Id,
    string Username,
    string Role,
    bool IsAdmin,
    bool MustChangePassword,
    UserPermissions Permissions = UserPermissions.None,
    bool IsTraining = false)
{
    public bool Can(UserPermissions permission) =>
        IsAdmin || (Permissions & permission) == permission;
}

public sealed record StaffUser(
    long Id,
    int Slot,
    string Username,
    bool IsActive,
    bool CredentialsConfigured,
    UserPermissions Permissions);

public sealed record StaffUserUpdate(
    long Id,
    string Username,
    bool IsActive,
    UserPermissions Permissions,
    string NewPassword,
    string NewPin);

public sealed record AuthenticationResult(
    bool Success,
    string Message,
    AuthenticatedUser? User = null);

public interface IAuthenticationService
{
    Task InitializeAsync(CancellationToken ct = default);

    Task<AuthenticationResult> LoginWithPasswordAsync(
        string username,
        string password,
        CancellationToken ct = default);

    Task<AuthenticationResult> LoginWithPinAsync(
        string username,
        string pin,
        CancellationToken ct = default);

    Task ChangeAdminCredentialsAsync(
        string currentPassword,
        string newPassword,
        string newPin,
        CancellationToken ct = default);

    Task<IReadOnlyList<StaffUser>> GetStaffUsersAsync(
        CancellationToken ct = default);

    Task SaveStaffUserAsync(
        StaffUserUpdate user,
        string changedBy,
        CancellationToken ct = default);
}
