namespace TorPos.Core;

public static class TorRelease
{
    public const string Product = "TOR POS Pro";
    public const string Version = "0.7.33.807";
    public const string Revision = "R107";
    public const string UserAgentVersion = "0.7.33-R107";

    // Set this to the TOR/Demirkaan GmbH production code-signing certificate thumbprint
    // before enabling remote automatic updates. Empty intentionally blocks remote installs.
    public const string UpdateSignerThumbprint = "";
}
