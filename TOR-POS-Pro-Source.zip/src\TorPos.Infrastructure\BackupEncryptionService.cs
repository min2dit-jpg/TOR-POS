using System.Security.Cryptography;
using System.Text;
using TorPos.Core;

namespace TorPos.Infrastructure;

public sealed record BackupEncryptionStatus(bool Enabled, string RecoveryFingerprint);

/// <summary>
/// R76: at-rest encryption for backup files (AES-256-GCM), applied as a thin
/// post-processing step around the existing, already-tested backup writers
/// (DatabaseBackupService, FullBackupService) rather than inside them - their
/// own plain-file behavior is unchanged, and internal/ephemeral backups the
/// app immediately reads back (pre-migration safety snapshots) intentionally
/// stay unencrypted so a migration failure never depends on a recovery code.
///
/// The per-backup data key (DEK) is wrapped two ways, mirroring how BitLocker
/// combines an automatic unlock path with a manual recovery key:
///  - Windows DPAPI (LocalMachine scope): silent, automatic decrypt as long as
///    this same machine is available. Chosen over CurrentUser scope so any
///    admin/technician account on the register can restore, not only the
///    Windows login that happened to create the backup.
///  - A one-time recovery code, shown to the admin exactly once when
///    encryption is enabled. This is the only path that still works if the
///    machine itself is gone (disk failure, theft, replacement) - and,
///    fundamentally, if that code is lost AND the machine is gone, the
///    backup is unrecoverable by design; that is what "encrypted" means.
/// </summary>
public sealed class BackupEncryptionService
{
    private const string EnabledKey = "backup.encryption.enabled";
    private const string RecoveryKekProtectedKey = "backup.encryption.recovery_kek_protected";
    private const string RecoveryFingerprintKey = "backup.encryption.recovery_fingerprint";

    private static readonly byte[] DpapiEntropy = Encoding.UTF8.GetBytes("TOR-POS-BACKUP-DEK-v1");
    private static readonly byte[] Magic = Encoding.ASCII.GetBytes("TPEB");
    private const byte FormatVersion = 1;
    private const int KeyBytes = 32;
    private const int NonceBytes = 12;
    private const int TagBytes = 16;
    private const int FingerprintBytes = 4;

    private readonly ISettingsRepository _settings;

    public BackupEncryptionService(ISettingsRepository settings) => _settings = settings;

    public async Task<BackupEncryptionStatus> GetStatusAsync(CancellationToken ct = default)
    {
        var values = await _settings.LoadAllAsync(ct);
        var enabled = string.Equals(values.GetValueOrDefault(EnabledKey, "false"), "true", StringComparison.OrdinalIgnoreCase);
        var fingerprint = values.GetValueOrDefault(RecoveryFingerprintKey, "");
        return new BackupEncryptionStatus(enabled, fingerprint);
    }

    /// <summary>
    /// Generates a brand-new recovery code, wraps it as the recovery KEK, and
    /// enables encryption. The returned code is shown to the caller exactly
    /// once; TOR POS never stores or displays it again. Calling this again
    /// (e.g. "regenerate") supersedes the previous code for FUTURE backups
    /// only - backups already written can still only be recovered with the
    /// recovery code that was current when they were created, or on the
    /// original machine via DPAPI.
    /// </summary>
    public async Task<string> EnableAndGenerateRecoveryCodeAsync(CancellationToken ct = default)
    {
        var codeBytes = RandomNumberGenerator.GetBytes(16);
        var code = FormatRecoveryCode(codeBytes);
        var kek = DeriveKek(code);

        var protectedKek = Convert.ToBase64String(
            ProtectedData.Protect(kek, DpapiEntropy, DataProtectionScope.LocalMachine));

        var fingerprint = Convert.ToHexString(SHA256.HashData(kek)).AsSpan(0, FingerprintBytes * 2).ToString();

        await _settings.SaveManyAsync(new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            [EnabledKey] = "true",
            [RecoveryKekProtectedKey] = protectedKek,
            [RecoveryFingerprintKey] = fingerprint
        }, ct);

        return code;
    }

    public async Task DisableAsync(CancellationToken ct = default)
    {
        // Keeps the wrapped KEK in place (already-written backups remain
        // recoverable with the recovery code); only stops encrypting new ones.
        await _settings.SaveManyAsync(new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            [EnabledKey] = "false"
        }, ct);
    }

    /// <summary>
    /// Verifies a typed recovery code against the stored fingerprint without
    /// needing an actual backup file - lets the setup UI catch a typo
    /// immediately instead of only failing much later during a real restore.
    /// </summary>
    public async Task<bool> VerifyRecoveryCodeAsync(string candidate, CancellationToken ct = default)
    {
        var status = await GetStatusAsync(ct);
        if (string.IsNullOrWhiteSpace(status.RecoveryFingerprint)) return false;
        var kek = DeriveKek(candidate);
        var fingerprint = Convert.ToHexString(SHA256.HashData(kek)).AsSpan(0, FingerprintBytes * 2).ToString();
        return string.Equals(fingerprint, status.RecoveryFingerprint, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// If backup encryption is enabled, encrypts plainPath in place (writes
    /// "{plainPath}.tpe", deletes plainPath) and returns the new path.
    /// If disabled, returns plainPath unchanged - callers should always use
    /// the returned path, not assume the extension.
    /// </summary>
    public async Task<string> EncryptIfEnabledAsync(string plainPath, CancellationToken ct = default)
    {
        var values = await _settings.LoadAllAsync(ct);
        if (!string.Equals(values.GetValueOrDefault(EnabledKey, "false"), "true", StringComparison.OrdinalIgnoreCase))
            return plainPath;

        var protectedKek = values.GetValueOrDefault(RecoveryKekProtectedKey, "");
        if (string.IsNullOrWhiteSpace(protectedKek))
            return plainPath; // Enabled but never actually set up; fail open rather than silently losing the backup.

        var kek = ProtectedData.Unprotect(Convert.FromBase64String(protectedKek), DpapiEntropy, DataProtectionScope.LocalMachine);
        var fingerprint = values.GetValueOrDefault(RecoveryFingerprintKey, "");

        var dek = RandomNumberGenerator.GetBytes(KeyBytes);
        var plain = await File.ReadAllBytesAsync(plainPath, ct);
        var payloadNonce = RandomNumberGenerator.GetBytes(NonceBytes);
        var payloadTag = new byte[TagBytes];
        var payloadCipher = new byte[plain.Length];
        using (var payloadAes = new AesGcm(dek, TagBytes))
            payloadAes.Encrypt(payloadNonce, plain, payloadCipher, payloadTag);

        var dpapiWrapped = ProtectedData.Protect(dek, DpapiEntropy, DataProtectionScope.LocalMachine);

        var recoveryNonce = RandomNumberGenerator.GetBytes(NonceBytes);
        var recoveryTag = new byte[TagBytes];
        var recoveryWrappedDek = new byte[KeyBytes];
        using (var kekAes = new AesGcm(kek, TagBytes))
            kekAes.Encrypt(recoveryNonce, dek, recoveryWrappedDek, recoveryTag);

        var target = plainPath + ".tpe";
        await using (var output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        await using (var writer = new BinaryWriter(output))
        {
            writer.Write(Magic);
            writer.Write(FormatVersion);
            writer.Write(payloadNonce);
            writer.Write(payloadTag);
            writer.Write(dpapiWrapped.Length);
            writer.Write(dpapiWrapped);
            writer.Write(recoveryNonce);
            writer.Write(recoveryTag);
            writer.Write(recoveryWrappedDek);
            writer.Write(Convert.FromHexString(fingerprint.PadRight(FingerprintBytes * 2, '0')));
            writer.Write(payloadCipher);
            writer.Flush();
            output.Flush(true);
        }

        File.Delete(plainPath);
        return target;
    }

    public static bool LooksEncrypted(string path)
    {
        try
        {
            using var f = File.OpenRead(path);
            if (f.Length < Magic.Length) return false;
            Span<byte> header = stackalloc byte[Magic.Length];
            return f.Read(header) == Magic.Length && header.SequenceEqual(Magic);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Decrypts an encrypted backup container to a plain output file.
    /// Tries the local machine's DPAPI-wrapped key first (works unattended on
    /// the same machine); if that is unavailable/fails and no recovery code
    /// was supplied, throws RecoveryCodeRequiredException so the caller can
    /// prompt for one and retry.
    /// </summary>
    public static async Task DecryptAsync(string encryptedPath, string outputPlainPath, string? recoveryCode, CancellationToken ct = default)
    {
        var bytes = await File.ReadAllBytesAsync(encryptedPath, ct);
        using var stream = new MemoryStream(bytes);
        using var reader = new BinaryReader(stream);

        var magic = reader.ReadBytes(Magic.Length);
        if (!magic.SequenceEqual(Magic))
            throw new InvalidDataException("Keine verschlüsselte TOR-POS-Sicherung (Signatur fehlt).");
        var version = reader.ReadByte();
        if (version != FormatVersion)
            throw new InvalidDataException($"Unbekanntes Verschlüsselungsformat (Version {version}).");

        var payloadNonce = reader.ReadBytes(NonceBytes);
        var payloadTag = reader.ReadBytes(TagBytes);
        var dpapiLen = reader.ReadInt32();
        var dpapiWrapped = reader.ReadBytes(dpapiLen);
        var recoveryNonce = reader.ReadBytes(NonceBytes);
        var recoveryTag = reader.ReadBytes(TagBytes);
        var recoveryWrappedDek = reader.ReadBytes(KeyBytes);
        _ = reader.ReadBytes(FingerprintBytes);
        var payloadCipher = reader.ReadBytes((int)(stream.Length - stream.Position));

        byte[]? dek = null;

        if (recoveryCode is null && dpapiLen > 0)
        {
            try
            {
                dek = ProtectedData.Unprotect(dpapiWrapped, DpapiEntropy, DataProtectionScope.LocalMachine);
            }
            catch (CryptographicException)
            {
                // Different machine, or the local DPAPI key material is gone; fall through to recovery code.
            }
        }

        if (dek is null)
        {
            if (recoveryCode is null)
                throw new RecoveryCodeRequiredException();

            var kek = DeriveKek(recoveryCode);
            dek = new byte[KeyBytes];
            try
            {
                using var kekAes = new AesGcm(kek, TagBytes);
                kekAes.Decrypt(recoveryNonce, recoveryWrappedDek, recoveryTag, dek);
            }
            catch (CryptographicException)
            {
                throw new InvalidOperationException("Kurtarma kodu falsch oder Sicherung beschädigt.");
            }
        }

        var plain = new byte[payloadCipher.Length];
        using (var payloadAes = new AesGcm(dek, TagBytes))
        {
            try
            {
                payloadAes.Decrypt(payloadNonce, payloadCipher, payloadTag, plain);
            }
            catch (CryptographicException)
            {
                throw new InvalidOperationException("Entschlüsselung fehlgeschlagen: falscher Schlüssel oder beschädigte Sicherung.");
            }
        }

        await File.WriteAllBytesAsync(outputPlainPath, plain, ct);
    }

    private static byte[] DeriveKek(string recoveryCode) =>
        SHA256.HashData(Encoding.UTF8.GetBytes(NormalizeCode(recoveryCode)));

    private static string NormalizeCode(string code) =>
        new string(code.Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();

    private static string FormatRecoveryCode(byte[] bytes)
    {
        var hex = Convert.ToHexString(bytes); // 32 hex chars for 16 bytes
        var groups = Enumerable.Range(0, hex.Length / 4).Select(i => hex.Substring(i * 4, 4));
        return string.Join("-", groups);
    }
}

public sealed class RecoveryCodeRequiredException : Exception
{
    public RecoveryCodeRequiredException()
        : base("Diese Sicherung kann auf diesem Computer nicht automatisch entschlüsselt werden. Wiederherstellungscode erforderlich.")
    {
    }
}
