using TorPos.Core;

namespace TorPos.Infrastructure;

/// <summary>
/// Central fail-safe wrapper for productive TSE operations.
///
/// Legal behavior:
/// - TSE failure is documented automatically.
/// - Failure of the TSE alone must not be treated like a successful signature.
/// - Higher layers may continue a sale in a controlled "TSE-Ausfall" mode,
///   but the receipt must be marked accordingly.
/// - On the first later successful TSE operation the open outage is closed.
///
/// This service does NOT silently fabricate TSE values.
/// </summary>
public sealed class TseFailSafeService
{
    private readonly ITseProvider _provider;
    private readonly ITseOutageRepository _outages;
    private readonly IAuditLog _audit;

    public TseFailSafeService(
        ITseProvider provider,
        ITseOutageRepository outages,
        IAuditLog audit)
    {
        _provider = provider;
        _outages = outages;
        _audit = audit;
    }

    public async Task<TseProbeResult> ProbeAsync(
        string actor = "SYSTEM",
        CancellationToken ct = default)
    {
        try
        {
            var result =
                await _provider.ProbeAsync(ct);

            if (result.State == TseConnectionState.Ready)
            {
                await _outages.CloseOpenAsync(actor, ct);
            }
            else if (result.State is
                     TseConnectionState.SdkMissing or
                     TseConnectionState.NotFound or
                     TseConnectionState.Error)
            {
                await _outages.OpenAsync(
                    result.Message,
                    actor,
                    ct);
            }

            return result;
        }
        catch (Exception ex)
        {
            await _outages.OpenAsync(
                $"{ex.GetType().Name}: {ex.Message}",
                actor,
                ct);

            await _audit.WriteAsync(
                actor,
                "TSE_PROBE_EXCEPTION",
                "TSE",
                "",
                ex.GetType().Name,
                ct);

            return new TseProbeResult(
                TseConnectionState.Error,
                $"TSE-Fehler: {ex.Message}");
        }
    }

    public async Task<(TseTransactionResult Result, bool TseOutage)>
        StartTransactionAsync(
            TseTransactionStartRequest request,
            string actor,
            CancellationToken ct = default)
    {
        try
        {
            var result =
                await _provider.StartTransactionAsync(
                    request,
                    ct);

            if (result.Success)
            {
                await _outages.CloseOpenAsync(actor, ct);
                return (result, false);
            }

            await _outages.OpenAsync(
                result.Message,
                actor,
                ct);

            return (result, true);
        }
        catch (Exception ex)
        {
            await _outages.OpenAsync(
                $"{ex.GetType().Name}: {ex.Message}",
                actor,
                ct);

            return (
                new TseTransactionResult(
                    false,
                    $"TSE-Ausfall: {ex.Message}"),
                true);
        }
    }

    public async Task<(TseTransactionResult Result, bool TseOutage)>
        FinishTransactionAsync(
            TseTransactionFinishRequest request,
            string actor,
            CancellationToken ct = default)
    {
        try
        {
            var result =
                await _provider.FinishTransactionAsync(
                    request,
                    ct);

            if (result.Success)
            {
                await _outages.CloseOpenAsync(actor, ct);
                return (result, false);
            }

            await _outages.OpenAsync(
                result.Message,
                actor,
                ct);

            return (result, true);
        }
        catch (Exception ex)
        {
            await _outages.OpenAsync(
                $"{ex.GetType().Name}: {ex.Message}",
                actor,
                ct);

            return (
                new TseTransactionResult(
                    false,
                    $"TSE-Ausfall: {ex.Message}"),
                true);
        }
    }
}
