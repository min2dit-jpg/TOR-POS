# Stand R51

R48 baut auf R47/R46/R45/R43/R42 auf:
- [x] Automatische fortlaufende Artikel-Nr. für neue Artikel (ab 100000)
- [x] Additive Nachnummerierung bestehender Artikel ohne Artikel-Nr.
- [x] Bestehende/importierte Artikelnummern bleiben erhalten
- [x] IMBISS: tägliche Abholnummer 001, 002, 003 … pro abgeschlossenem Verkauf
- [x] Abholnummer auf Bon, Bon-Historie und TOR POS Cloud
- [x] TRAINING nutzt nur eine lokale Sitzungssequenz und verbraucht keine Produktiv-Abholnummer
- [x] Cloud Regression 15/15
- [ ] Windows-Build / echter Bon-Druck mit großer Abholnummer auf 58/80 mm am Kassen-PC
- [ ] 10.000 Artikel / 500.000 Verkauf Lasttest und realer Scanner-/Drucker-/Terminal-End-to-End-Test

Nächste IMBISS-Prioritäten: Menü/Combo, zweiter Küchenbon/Küchendrucker und Mehrsprachigkeit. Lieferplattformen folgen als getrennte Integrationsschicht.
Fiskalische Produktion bleibt bis realer TSE-/DSFinV-K-End-to-End-Abnahme gesperrt.

# Roadmap

## Core v0.2
[x] .NET cross-platform temel
[x] SQLite WAL
[x] RAM product cache
[x] barcode scanner
[x] product images
[x] variants / sizes
[x] Pfand
[x] BAR / KARTE local sales
[x] Kiosk / Imbiss
[x] performance counters

## Core v0.2
[x] Schnellartikel / freie Preiseingabe
[x] Menü / Combo (bereits seit R49 fertig, Checkbox war nur nicht aktualisiert)
[x] Extras / Zutaten
[x] Im Haus / Außer Haus tax rules (R95: §12 UStG - ImHausVat.Effective hebt 7% auf 19% an, Bruttopreis bleibt gleich, Umschalter nur im IMBISS-Betrieb; R96: Auswahl überlebt Parken/Absturz-Wiederherstellung; R97: pro Warengruppe abschaltbar; R98: CSV/DB-Import in bestehende Warengruppen vererbt die Einstellung korrekt statt sie zurückzusetzen; R99: CSV-Export + DB-zu-DB-Import tragen die Einstellung jetzt ebenfalls mit, voller Roundtrip auf einer frischen/wiederhergestellten Datenbank)
[x] R100: Artikel-Import zwischen zwei unabhängig erstellten TOR-POS-Installationen scheiterte immer an einem globalen Barcode-Unique-Index vs. scope-gefilterter Duplikatsprüfung (beide Installationen seeden denselben Demo-Barcode unter KIOSK-Scope) - Duplikatsprüfung jetzt konsistent mit dem echten globalen Constraint
[x] Rückgabe / Storno journal (R88: bestehender "STORNOBERICHT" erfasste Teilretouren und SOFORT-STORNO nie korrekt - neu aufgebaut als "STORNO- UND RETOURENJOURNAL")
[x] kullanıcı / PIN / yetki
[x] gerçek bon queue
[x] bon yeniden yazdırma
[x] stok temeli
[x] thumbnail generation (R87: Bitmap.DecodeToWidth statt Volldekodierung für Artikelkacheln)
[x] crash recovery
[x] 10k ürün / 500k satış benchmark (R84: PASS, 12,4s - Checkbox war nur nicht aktualisiert, siehe unten "R48 ve sonrası")

## Fiscal v0.4
(Diese ganze Sektion war eine frühe grobe Planungsliste, nie aktualisiert, nachdem die eigentliche Arbeit unter "Swissbit Runtime v0.6.8"/"Deutschland Fiscal Hardening v0.6.0" viel detaillierter erledigt wurde - Checkboxen waren nur nicht nachgezogen worden.)
[x] TSE abstraction (`ITseProvider`, siehe Swissbit Runtime v0.6.8)
[x] TSE vendor adapter (`SwissbitHardwareTseProvider`, siehe Swissbit Runtime v0.6.8)
[x] transaction lifecycle (StartTransaction/UpdateTransaction/FinishTransaction, siehe Swissbit Runtime v0.6.8)
[x] TSE fail mode (`TseFailSafeService`/`TseOutageRepository`, R78 TSE-Ausfall-Log Schema)
[x] fiscal receipt data (KassenSichV-Fiskalfelder im Receipt-Modell, siehe Deutschland Fiscal Hardening v0.6.0)
[ ] DSFinV-K (echter Export bleibt Entwurf/gesperrt - siehe Deutschland Fiscal Hardening v0.6.0 und Swissbit Runtime v0.6.8, "DSFinV-K 2.4 end-to-end validation")
[x] audit log (`IAuditLog`/`audit_log`, durchgängig genutzt seit den ersten Revisionen)

## Payment v0.4
(Gleiche Situation wie "Fiscal v0.4" oben - siehe "Payment Terminal v0.6.1" für die eigentliche, aktuelle Tracking-Sektion.)
[x] ZVT (siehe Payment Terminal v0.6.1)
[x] terminal config (IP/Port/Timeouts in Einstellungen → Zahlarten → Kartenterminal)
[x] success/failure state machine (`checkout_operations`: PREPARED→SENT→APPROVED/NOT_CHARGED/UNKNOWN→COMMITTED)
[x] mixed payment (R101: GEMISCHT-Button, Bar-Anteil sofort kassiert, Karten-Anteil exakt an Terminal, TSE ProcessData/Berichte/Kassensturz korrekt aufgeteilt; Storno/Retoure vorerst wie KARTE gesperrt)
[x] timeout isolation (`CommandTimeoutSeconds`/`CancellationTokenSource`, siehe ZvtPaymentTerminalService)


## Office / Einstellungen v0.2
[x] Profesyonel sol navigasyon
[x] Firmendaten
[x] Funktionen
[x] Zahlarten
[x] Steuer / DATEV hazırlığı
[x] Bon ayarları
[x] Geräte-Manager konfigürasyonu
[x] Scanner ayarları
[x] Datensicherung + path test + manuel backup
[x] Personal/Rechte çerçevesi
[x] Sistem ve performance görünümü


## v0.4 – Installationsprofil / TSE
[x] KIOSK / IMBISS Auswahl im Installer
[x] Installationsversion dauerhaft sperren
[x] Versionswechsel aus Kassenoberfläche entfernen
[x] Versionswechsel aus Einstellungen entfernen
[x] KIOSK Scanner-Fokus
[x] IMBISS Schnellwahl-Fokus
[x] Einstellungen -> TSE-Aktivierung
[x] TSE-Metadatenfelder
[x] PIN / PUK nicht persistent speichern
[ ] Echter TSE-Geräteadapter
[ ] TSE-Verbindungstest gegen reale Hardware
[ ] TSE-Aktivierung / Admin-Authentifizierung
[ ] TSE-Transaktionslebenszyklus
[ ] DSFinV-K mit realen TSE-Daten


## Swissbit Fiscal Adapter v0.4
[x] Swissbit Hardware TSE 2 standard provider
[x] USB as TOR standard form factor
[x] ITseProvider abstraction
[x] Swissbit SDK bridge boundary
[x] TSE metadata auto-read fields
[x] Admin-PIN / PUK non-persistent
[x] Settings fixed to Swissbit standard
[ ] Obtain official Swissbit SDK / drivers
[ ] Implement documented native SDK bridge
[ ] Real Hardware TSE 2 USB detection test
[ ] Real activation test
[ ] Transaction start/finish signing
[ ] TSE removal / timeout / recovery tests
[ ] Fiscal receipt fields
[ ] DSFinV-K real-data validation


## Printer v0.4.2
[x] Star mC-Print3 MCP31CBI standard receipt printer
[x] Windows installed-printer discovery
[x] MCP31 / mC-Print3 auto detection
[x] 80 mm receipt layout
[x] Test receipt
[x] Auto receipt after sale
[x] Dedicated background print queue
[x] Printer failure does not block UI thread
[ ] Direct StarPRNT SDK status
[x] Direct cutter command (R86: StarPRNT/ESC-POS GS V via Windows RAW spooler passthrough, no StarIO10 SDK needed)
[x] Direct DK cash-drawer command (R86: ESC p, cash sales only, opt-out in Einstellungen)
[~] Paper-out monitoring (R89: Live-Statuscheck vor jedem einzelnen Druckauftrag, kein kontinuierliches Push-Monitoring während der Warteschlange - dafür weiterhin StarIO10-SDK oder direkte Portanbindung nötig)


## Deutschland Fiscal Hardening v0.6.0
[x] eAS-Seriennummer einmalig / unveränderbar
[x] Recht & Fiskal Statusseite
[x] Produktivbetrieb ohne Fiskalprüfung gesperrt
[x] Append-only Audit-Log
[x] Abgeschlossene Verkäufe programmintern unveränderbar
[x] Einlage / Entnahme mit Grund
[x] Kassensturz-Sollbestand technische Basis
[x] TSE-Ausfall-Log Schema
[x] Testbon klar als nicht produktiv gekennzeichnet
[x] MwSt.-Zusammenfassung auf Testbon
[x] KassenSichV-Fiskalfelder im Receipt-Modell vorbereitet
[x] §146a Meldestatus dokumentierbar
[x] Verfahrensdokumentations-Vorlage
[ ] Offizielles Swissbit SDK / reale TSE-Signierung
[ ] Parken als TSE Bestellung / SonstigerVorgang
[ ] DSFinV-K 2.4 vollständiger Export
[ ] TSE TAR Export
[x] R79: BON STORNO (volle Gegenbuchung eines abgeschlossenen Bons); R102: KARTE-Storno/Teilretoure per ZVT RefundAsync (manuelle Gutschrift, Karte erneut vorgelegt) umgesetzt - keine Beschränkung mehr auf BAR
[x] R103: Digitaler Bon per QR-Code - lokaler Webserver auf der Kasse (kein Cloud-Hosting, keine Admin-Rechte nötig), QR erscheint nur wenn BON EIN/AUS ausgeschaltet ist, kein Papier nötig
[x] R104: Kundendisplay (z. B. HP L7010t) - echter zweiter Bildschirm zeigt Warenkorb/Summe live und "Vielen Dank" inkl. R103-QR-Code; "Kundenanzeige"-Einstellung existierte vorher nur als leeres Gerüst (COM-Port-Feld, nie implementiert)
[x] R106: eigene Quellcode-Prüfung des Nutzers (1. Runde) - Retoure-Rabattanteil unprorated, digitaler Bon-MwSt bei Rabatt falsch, keine dauerhafte Sperre gegen doppelten Kartenerstattungsversuch - alle drei behoben
[x] R107: eigene Quellcode-Prüfung des Nutzers (2. Runde) - Kartenerstattung lief vor Prüfung auf bereits erfolgte Stornierung/Retoure (Terminal wurde zuerst belastet), Storno/Teilretoure prüften sich gegenseitig nicht (Doppelerstattung möglich, z. B. 130 € Erstattung auf 100 € Bon), digitaler Bon verwechselte TSE-Ausfall mit Testbon - alle drei behoben; zusätzlich reject()-Testmethodik um Nachrichtenprüfung erweitert (RejectMessage), damit ein Test nachweislich das GEMEINTE Gate prüft, nicht ein früheres
[x] R78: direkter Kassenverkauf (KIOSK/IMBISS SALE) ruft TSE Start+Finish als ein Beleg auf; ProcessData-Format ist Entwurf, noch nicht gegen BSI TR-03153 verifiziert
[ ] Produktiver Z-Abschluss
[ ] Pfand-Steuerlogik fachlich final validieren
[ ] End-to-End Kassen-Nachschau Test


## Payment Terminal v0.6.1
[x] IPaymentTerminalService
[x] ZVT TCP/IP adapter
[x] Portalum.Zvt 3.4.0 stable package
[x] ZVT connection test
[x] ZVT registration test
[x] amount transfer on KARTE
[x] card sale only after terminal success
[x] Ingenico / CCV / Verifone profiles
[x] PAX / other ZVT test profile
[x] PCI-safe logging without PAN/PIN/CVV
[ ] Real Ingenico Germany acceptance test
[ ] Real CCV Germany acceptance test
[ ] Real Verifone/TeleCash acceptance test
[ ] ZVT serial/USB transport
[x] Refund/reversal UI (R102: RefundAsync via BON STORNO/Teilretoure, real Terminal-Akzeptanztest noch offen)
[x] Terminal end-of-day UI (R94: ZVT End-of-Day 06 50 - eigener Settings-Bereich, getrennt vom Verbindungsstatus)
[ ] SumUp official adapter
[ ] Stripe Terminal adapter
[ ] Adyen Terminal API adapter


## Swissbit Runtime v0.6.8
[x] WormAPI.dll dynamic loading
[x] official SDK folder/package hook
[x] API version/export diagnostics
[x] Windows TSE drive detection
[x] TSE info/serial/certificate expiry read
[x] guarded worm_tse_setup flow
[x] client registration
[x] self test / CTSS / time update
[x] StartTransaction
[x] UpdateTransaction
[x] FinishTransaction
[x] transaction response fiscal fields
[x] TAR export
[x] synchronized native SDK calls
[ ] official Hardware TSE 2 SDK package supplied to TOR test environment
[ ] real Hardware TSE 2 acceptance test
[ ] secure persistent TimeAdmin credential strategy
[x] fiscal ProcessData/ProcessType generator (Entwurf, siehe FiscalProcessData - nicht final verifiziert)
[x] Parken → Bestellung TSE lifecycle (R83: eigener "Bestellung-V1"-Vorgang bei ORDER-Annahme, getrennt vom Kassenbeleg-V1 bei Zahlung)
[x] sale → Kassenbeleg TSE lifecycle (R78, direkter Verkauf; R83 ergänzt IMBISS ORDER-Annahme)
[ ] DSFinV-K 2.4 end-to-end validation

## v0.7.33 – Bedienkomfort / Frontend Simplification
[x] Rakip inceleme yönü: POSprom + LaCash + KasseSpeedy + BlitzHandel + Blitzkasse
[x] Tasarım ilkesi: günlük kasiyer ekranında yalnız günlük işlemler
[x] Nadir işlemleri ana hızlı işlem şeridinden kaldır
[x] Bon-Historie / Einlage-Entnahme / Z-Bericht / Bon-Storno -> KASSE menüsü
[x] Rabatt / Geparkte Bons / Bon Ein-Aus doğrudan erişimde kalır
[x] Einstellungen ana navigasyonunu Basit / Erweitert olarak sadeleştir
[x] İlk kurulum sihirbazı: Firma -> Drucker -> TSE -> Kartenterminal -> Fertig
[x] Kasiyer ekranında bağlama duyarlı işlem görünürlüğü (Checkbox war nur nicht aktualisiert - bereits umfassend vorhanden: `RefreshSalesActionState` steuert Zahl-/Mengen-/Storno-/Rabatt-/Park-Buttons nach Warenkorbzustand+Rechten, der Settings-Reload-Block in `ReloadSettingsAsync` nach Rechten/Trainingsmodus/Business-Modus, dazu `RefreshImHausToggle`/`RefreshReceiptModeButtons`/`RefreshLicenseWarning` für ihre jeweiligen Zustände - kein fehlendes Feature, R100-Session-Audit bestätigt)
[x] Hata mesajlarını müşteri dili + Techniker-Details şeklinde ayır (R85: ScannerStatus zeigt nur Kategorie + Fehler-ID; volle Exception nur im CrashLog, per Fehler-ID-Suche im Diagnose-Fenster abrufbar)
[x] 3-tık kuralı: sık işlemler <= 1, yönetim işlemleri <= 3 dokunuş


## R48 ve sonrası – KIOSK / IMBISS rekabet boşlukları
[x] Yeni Artikel için otomatik, kalıcı Artikel-Nr.
[x] Mevcut numarasız Artikel kayıtlarını additive migration ile numaralandır
[x] IMBISS günlük Abholnummer / sıra numarası (Bon + Historie + Cloud)
[x] IMBISS Menü / Combo (örn. Döner + Pommes + Getränk) - R49'da zaten tamamlanmış, bu liste güncellenmemişti
[x] İkinci Küchenbon / Küchen-Drucker routing (R77: Warengruppe -> Küchenstation)
[ ] Arayüz dili: DE + TR + EN; ardından AR için RTL uygunluğu
[x] Sağlayıcı/middleware değerlendirmesi tamamlandı (`LIEFERPLATTFORM-INTEGRATION-BEWERTUNG-DE.md`) - öneri: Deliverect/allO gibi tek bir aggregator, doğrudan 3 platform entegrasyonu değil
[ ] Lieferando / Wolt / Uber Eats entegrasyon katmanı - aggregator seçimi + "TOR POS Cloud" webhook-endpoint kararı kullanıcıya ait, henüz verilmedi
[x] Tamamlanmış satış için gerçek Rückgabe / Storno fiskal karşı-vorgang (R79 tam bon, R82 kısmi/tekil ürün Retoure - ikisi de sadece BAR)
[x] Direct cutter / drawer via StarPRNT RAW spooler commands (R86)
[~] Paper-out: pre-print Windows status check added (R89); real Direct StarPRNT SDK status still needs official StarIO10 SDK or direct port access
[x] 10.000 Artikel / 500.000 Verkauf benchmark (R84: PASS, 12,4 s Gesamtdauer, 500k Sales+Items in 8,7 s; siehe verification/R74/)
[ ] Gerçek Windows PC + Scanner + Bon-Drucker + Kartenterminal uçtan uca saha kabul testi


## R49 – IMBISS Bestellablauf / Menü / Küche / Sprache
- [x] Menü/Combo direkt im Artikelstamm
- [x] Combo-Bestandteile werden für Lagerverbrauch verwendet
- [x] Zweiter Küchendrucker als eigener Windows-Drucker
- [x] Küchenbon über persistente TOR-Druckwarteschlange
- [x] UI-Sprache DE / TR / EN
- [x] Bon / Küchenbon / Berichte / fiskalische Ausdrucke bleiben Deutsch
- [x] Abholnummer optional: OFF / SALE / ORDER
- [x] ORDER: Abholnummer bei Bestellannahme, finaler Bon erst bei späterer Zahlung
- [ ] Weitere UI-Sprachen schrittweise ergänzen (z. B. AR/FR/ES)
- [x] Küchenrouting nach Warengruppe/Station (Grill, Fritteuse, Getränke) - R77
- [ ] Gemischte MwSt.-Menüs erst nach fiskaler Endvalidierung für Produktivbetrieb freigeben

## R51 – IMBISS Produktbilder / Login-Sprache / Stammdaten

- [x] Programmsprache DE/TR/EN direkt auf der Anmeldung auswählbar und persistent.
- [x] Gedruckte/fiskale Ausgaben bleiben Deutsch.
- [x] IMBISS-Starterhierarchie Speisen/Getränke repariert; KIOSK-Demogruppen im IMBISS ausgeblendet.
- [x] Gruppe/Warengruppe/Artikel als auditierte Soft-Deaktivierung löschbar (Admin).
- [x] 57 lokale Produktbilder für das IMBISS-Starter-Sortiment; Kundenbilder werden nicht überschrieben.
- [ ] Windows/.NET-Compile und echter Geräte-Abnahmetest.
