using TorPos.Core;

namespace TorPos.Infrastructure;

/// <summary>
/// R78: post-commit TSE fiscal signing for one completed direct sale
/// (KIOSK checkout and IMBISS SALE-mode checkout only - the IMBISS
/// ORDER/Bestellung lifecycle is a separate, not-yet-covered TSE Vorgang).
///
/// Runs strictly AFTER the sale row is already durably committed via
/// ISaleRepository.CommitAsync. TSE signing failure (TSE-Ausfall) can never
/// block, roll back or alter an already-completed sale - it only means the
/// sale's TSE fields stay empty and the failure is logged through
/// TseFailSafeService/ITseOutageRepository, exactly like every other TSE
/// operation in this codebase.
///
/// One Kassenbeleg is signed as a single Start+Finish TSE transaction
/// (process type <see cref="FiscalProcessData.KassenbelegProcessType"/>).
/// See FiscalProcessData for the important caveat about its ProcessData
/// format not yet being legally validated.
///
/// NOTE: FiscalComplianceService currently hard-gates ProductionAllowed to
/// false (fiscalReleaseBuild=false in code), so MainWindow's real
/// (non-simulation) checkout path cannot reach this service in the shipped
/// build today. It exists so the wiring can be built and tested ahead of
/// that gate being lifted - it does not by itself make TOR POS fiscally
/// production-ready.
/// </summary>
public sealed class SaleFiscalSigningService
{
    private readonly TseFailSafeService _tse;
    private readonly ISettingsRepository _settings;
    private readonly ISaleRepository _sales;

    public SaleFiscalSigningService(
        TseFailSafeService tse,
        ISettingsRepository settings,
        ISaleRepository sales)
    {
        _tse = tse;
        _settings = settings;
        _sales = sales;
    }

    public async Task SignAsync(Sale sale, string actor, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(sale);

        var settings = await _settings.LoadAllAsync(ct);

        if (!string.Equals(settings.GetValueOrDefault("tse.status"), "AKTIV", StringComparison.OrdinalIgnoreCase))
            return;

        var clientId = (settings.GetValueOrDefault("tse.client_id") ?? "").Trim();
        if (clientId.Length == 0)
            return;

        var processData = FiscalProcessData.BuildKassenbeleg(sale);

        var (startResult, _) = await _tse.StartTransactionAsync(
            new TseTransactionStartRequest(clientId, processData, FiscalProcessData.KassenbelegProcessType),
            actor,
            ct);

        if (!startResult.Success)
        {
            await ApplyAsync(sale, SaleTseResult.Outage(startResult.Message), ct);
            return;
        }

        var (finishResult, _) = await _tse.FinishTransactionAsync(
            new TseTransactionFinishRequest(clientId, startResult.TransactionNumber, processData, FiscalProcessData.KassenbelegProcessType),
            actor,
            ct);

        if (!finishResult.Success)
        {
            await ApplyAsync(sale, SaleTseResult.Outage(finishResult.Message), ct);
            return;
        }

        var result = SaleTseResult.SignedResult(
            clientId,
            finishResult.TransactionNumber.ToString(),
            finishResult.SignatureCounter.ToString(),
            finishResult.SerialNumber,
            finishResult.SignatureBase64,
            finishResult.LogTime);

        await ApplyAsync(sale, result, ct);
    }

    private async Task ApplyAsync(Sale sale, SaleTseResult result, CancellationToken ct)
    {
        await _sales.RecordTseResultAsync(sale.Id, result, ct);

        // Mutate the in-memory Sale too so the immediate post-commit receipt
        // print (same request, same object) reflects the signature without
        // a redundant re-read from the database.
        sale.TseClientId = result.ClientId;
        sale.TseTransactionNumber = result.TransactionNumber;
        sale.TseSignatureCounter = result.SignatureCounter;
        sale.TseSerialNumber = result.SerialNumber;
        sale.TseSignature = result.Signature;
        sale.TseLogTime = result.LogTime;
        sale.TseOutage = !result.Signed;
    }
}
